import React from 'react';
import {
    TextInput, Text, View, TouchableOpacity,
    Image, ScrollView, Alert, ImageBackground,
} from 'react-native';
import styles from './styles';
import { StatusBar } from 'expo-status-bar';
import defaultAdmin from "../../img/defaultAdmin.jpg";
import CadastroLinha from '../../components/cadastroLinha';
import { useState, useEffect } from 'react';
import CadastroView from '../../components/cadastroView'
import {
    createTableCategoria,
    obtemTodasAsCategorias,
    adicionaCategoria,
    alteraCategoria,
    excluiCategoria,
    excluiTodasAsCategorias,
} from '../../services/databaseAdm';

export default function Category({ navigation }) {
    const [nome, setNome] = useState("");
    const [id, setId] = useState("");
    const [categorias, setCategorias] = useState([]);

    useEffect(
        () => {
            useEffectAwait();
        }, []);

    async function useEffectAwait() {
        if (!tableExist) {
            tableExist = true;
            await createTableCategoria();
            console.log('criou tabela')
        }

        await Carregar();
    }

    let tableExist = false;

    function Limpar() {
        setId("");
        setNome("");
    }

    async function Salvar() {
        if (nome == "") {
            alert("Escreva o nome");
            return;
        }

        let novoRegistro = !id;

        let objCategoria = {
            id: novoRegistro ? createUniqueId() : id,
            nome: nome
        };

        if (novoRegistro) {
            let resposta = (await adicionaCategoria(objCategoria));
            if (resposta)
                alert('adicionado');
            else
                alert('deu erro em adicionar');
        }
        else {
            let resposta = await alteraCategoria(objCategoria);
            if (resposta)
                alert('alterado');
            else
                alert('deu erro na alteração');
        }

        Limpar();
        await Carregar();
    }

    function createUniqueId() {
        return Date.now().toString(36) + Math.random().toString(36).slice(0, 2);
    }

    function editar(identificador) {
        const objCategoria = categorias.find(categoria => categoria.id == identificador);

        if (objCategoria) {
            setId(objCategoria.id);
            setNome(objCategoria.nome);
        }
    }

    async function efetivaRemoverItem(identificador) {
        try {
            await excluiCategoria(identificador);
            alert('removido');
            Limpar();
            await Carregar();
        } catch (e) {
            alert(e.toString());
        }
    }

    async function Carregar() {
        try {
            let listaCategorias = await obtemTodasAsCategorias();
            setCategorias(listaCategorias);
        } catch (e) {
            alert(e.toString());
        }
    }

    return (
        <View style={styles.container}>
            <ImageBackground source={defaultAdmin} style={styles.imageBackground}>
                <ScrollView style={styles.container}>

                    <Text style={styles.tituloDaPizzaria}>Categorias:</Text>
                    <View>
                        <CadastroLinha placeholder={'Digite a categoria aqui'}
                            texto={nome}
                            setTexto={setNome}
                            titulo={'Nome'} />

                        <TouchableOpacity
                            style={styles.botaoCaixa2}
                            onPress={() => Salvar()}>
                            <Text style={styles.tituloPizzaria}>Salvar</Text>
                        </TouchableOpacity>
                    </View>
                    <ScrollView style={styles.container}>
                        {
                            categorias.map((categoria, index) => (
                                <CadastroView item={categoria}
                                    editar={editar}
                                    efetivaRemoverItem={efetivaRemoverItem}
                                    key={index.toString()} />
                            ))
                        }
                    </ScrollView>
                </ScrollView>

                <View>
                    <TouchableOpacity
                        style={styles.botaoCaixa1}
                        onPress={() => { navigation.navigate('Administrator') }}>
                        <Text style={styles.tituloPizzaria}>Voltar</Text>
                    </TouchableOpacity>
                </View>
            </ImageBackground>
        </View>
    );
}