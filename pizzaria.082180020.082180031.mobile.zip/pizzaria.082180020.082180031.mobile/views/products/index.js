import React from 'react';
import {
    TextInput, Text, View, TouchableOpacity,
    Image, ScrollView, Alert, ImageBackground,
} from 'react-native';
import styles from './styles';

import defaultAdmin from "../../img/defaultAdmin.jpg";
import CadastroLinha from '../../components/cadastroLinha';
import CadastroNumber from '../../components/cadastroNumber';
import CadastroDropdown from '../../components/cadastroDropdown';
import { useState, useEffect } from 'react';
import CadastroView from '../../components/cadastroView'
import {
    createTableProduto,
    obtemTodasAsCategorias,
    adicionaProduto,
    alteraProduto,
    excluiProduto,
    obtemTodosProdutos,
} from '../../services/databaseAdm';


export default function Products({ navigation }) {
    const [nome, setNome] = useState("");
    const [id, setId] = useState("");
    const [preco, setPreco] = useState("");
    const [categorias, setCategorias] = useState([]);
    const [categoria, setCategoria] = useState("");
    const [descricao, setDescricao] = useState("");
    const [produtos, setProdutos] = useState([]);

    useEffect(
        () => {
            useEffectAwait();
        }, []);

    async function useEffectAwait() {
        if (!tableExist) {
            tableExist = true;
            await createTableProduto();
            console.log('criou tabela')
        }

        await Carregar();
    }

    let tableExist = false;

    function Limpar() {
        setId("");
        setNome("");
        setPreco("");
        setCategoria("");
        setDescricao("");
    }

    async function Carregar() {
        try {
            let listaProdutos = await obtemTodosProdutos();
            let listaCategorias = await obtemTodasAsCategorias();
            setProdutos(listaProdutos);
            setCategorias(listaCategorias);
        } catch (e) {
            alert(e.toString());
        }
    }

    async function Salvar() {
        if (nome == "") {
            alert("Nome da pizza deve ser escrito");
            return;
        }
        if (descricao == "") {
            alert("Descrição deve ser escrita");
            return;
        }
        if (preco == "") {
            alert("Preço deve ser escrito");
            return;
        }
        if (parseFloat(preco) <= 0) {
            alert("Preço deve ser maior que zero");
            return;
        }
        if (categoria == "") {
            alert("Categoria deve ser escrita");
            return;
        }

        let novoRegistro = !id;

        let objProduto = {
            id: novoRegistro ? createUniqueId() : id,
            nome: nome,
            descricao: descricao,
            preco: preco,
            categoria: categoria
        };

        if (novoRegistro) {
            let resposta = (await adicionaProduto(objProduto));
            if (resposta)
                alert('novo registro salvo');
            else
                alert('erro ao adicionar novo registro');
        }
        else {
            let resposta = await alteraProduto(objProduto);
            if (resposta)
                alert('registro alterado');
            else
                alert('erro ao alterar o registro');
        }

        await Carregar();
    }

    function createUniqueId() {
        return Date.now().toString(36) + Math.random().toString(36).slice(0, 2);
    }

    function editar(identificador) {
        const objProduto = produtos.find(produto => produto.id == identificador);

        setId(objProduto.id);
        setNome(objProduto.nome);
        setDescricao(objProduto.descricao);
        setPreco(objProduto.preco.toString());
        setCategoria(objProduto.categoria);
    }

    async function efetivaRemoverItem(identificador) {
        try {
            await excluiProduto(identificador);
            alert('Produto excluído');
            Limpar();
            await Carregar();
        } catch (e) {
            alert(e.toString());
        }
    }

    return (
        <View style={styles.container}>
            <ImageBackground source={defaultAdmin} style={styles.imageBackground}>
                <ScrollView style={styles.container}>

                    <Text style={styles.tituloDaPizzaria}>Categorias:</Text>
                    <View>
                        <CadastroLinha placeholder={'Digite o nome do produto'}
                            texto={nome}
                            setTexto={setNome}
                            titulo={'Nome'} />

                        <CadastroLinha placeholder={'Digite a descrição do produto'}
                            texto={descricao}
                            setTexto={setDescricao}
                            titulo={'Descrição'} />

                        <CadastroNumber
                            placeholder={'Digite o preço aqui'}
                            texto={preco}
                            setTexto={setPreco}
                            titulo={'Preço'} />

                        <CadastroDropdown
                            categoria={categoria}
                            lista={categorias}
                            setCategoria={setCategoria}
                            titulo={'Categoria'} />

                        <TouchableOpacity
                            style={styles.botaoCaixa1}
                            onPress={() => Salvar()}>
                            <Text style={styles.tituloPizzaria}>Salvar</Text>
                        </TouchableOpacity>
                    </View>
                    <ScrollView style={styles.container}>
                        {
                            produtos.map((produto, index) => (
                                <CadastroView item={produto}
                                    editar={editar}
                                    efetivaRemoverItem={efetivaRemoverItem}
                                    key={index.toString()} />
                            ))
                        }
                    </ScrollView>
                </ScrollView>
                <View>
                    <TouchableOpacity
                        style={styles.botaoCaixa2}
                        onPress={() => { navigation.navigate('Administrator') }}>
                        <Text style={styles.tituloPizzaria}>Voltar</Text>
                    </TouchableOpacity>
                </View>
            </ImageBackground>
        </View>
    );
}