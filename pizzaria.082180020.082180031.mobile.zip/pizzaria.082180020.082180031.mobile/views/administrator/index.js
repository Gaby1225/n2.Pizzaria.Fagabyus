import React from 'react';
import {
    TextInput, Text, View, TouchableOpacity,
    Image, ScrollView, Alert, ImageBackground,
} from 'react-native';
import styles from "./styles";

import defaultAdmin from "../../img/defaultAdmin.jpg";

export default function Administrator({ navigation }) {
    return (
        <View style={styles.container}>
            <ImageBackground source={defaultAdmin} style={styles.imageBackground}>
                <Text style={styles.tituloDaPizzaria}>Administrador</Text>
                <View>
                    <TouchableOpacity
                        style={styles.botaoCaixa1}
                        onPress={() => { navigation.navigate('Category') }}>
                        <Text style={styles.tituloPizzaria}>Cadastro de Categorias</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.botaoCaixa1}
                        onPress={() => { navigation.navigate('Products') }}>
                        <Text style={styles.tituloPizzaria}>Cadastro de Produtos</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.botaoCaixa1}
                        onPress={() => { navigation.navigate('Sales') }}>
                        <Text style={styles.tituloPizzaria}>Listar Vendas</Text>
                    </TouchableOpacity>
                </View>

                <View>
                    <TouchableOpacity
                        style={styles.botaoCaixa2}
                        onPress={() => { navigation.navigate('Home') }}>
                        <Text style={styles.tituloPizzaria}>Voltar</Text>
                    </TouchableOpacity>
                </View>

            </ImageBackground>
        </View>
    );
}