import React from 'react';
import {
    TextInput, Text, View, TouchableOpacity,
    Image, ScrollView, Alert, ImageBackground,
} from 'react-native';
import styles from "./styles";

import defaultFunds from "../../img/defaultFunds.jpg";
import { createTableVendas, adicionaVenda, obtemTodasVendas } from '../../services/databaseAdm';
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useState, useEffect } from 'react';

export default function Carrinho({ navigation }) {
    const [order, setOrder] = useState([]);
    const [total, setTotal] = useState(0);

    useEffect(
        () => {
            Carregar(); //Faz o que deveria ser feito no useEffect, mas assincronamente
        }, [total, order]);

    async function Carregar() {
        try {
            const jsonValue = await AsyncStorage.getItem('@order')
            const obj = JSON.parse(jsonValue);
            setOrder(obj);

        } catch (e) {
            alert(e.toString());
        }

        if (!confirmaTotal) {
            CalcularTotal();
        }
    }

    let confirmaTotal = false;

    function CalcularTotal() {
        let valor = 0;
        order.forEach(item => {
          valor += item.preco
        });
        confirmaTotal = true;
        setTotal(valor);
      }

    function createUniqueId() {
        return Date.now().toString(36) + Math.random().toString(36).slice(0, 2);
    }

    async function FinalizaOrder() {
        await createTableVendas();
        let descricaoString = '';
        order.forEach(item => {
          descricaoString += 'Item: ' + item.item.toString() + '\nQuantidade: ' + item.quantidade.toString() + '\nPreço: R$' + item.preco.toFixed(2).toString().replace('.', ',') + '\n\n';
        });
        const agora = new Date(Date.now()).toLocaleDateString();
        obj = {
          id: createUniqueId(),
          descricao: descricaoString,
          data: agora.toString(),
          total: total
        }
        console.log(obj)
        await adicionaVenda(obj);
        alert('Pedido finalizado!');
        navigation.navigate('Home');
      }

    return (
        <View style={styles.container}>
            <ImageBackground source={defaultFunds} style={styles.imageBackground}>
                <Text style={styles.tituloDaPizzaria}>Carrinho</Text>

                <ScrollView style={styles.container}>
                    {
                        order.map((item, index) => (
                            <View key={index.toString()}>
                              <Text style={styles.label}>Item: {item.item}</Text>
                              <Text style={styles.label}>Qtde: {item.quantidade}</Text>
                              <Text style={styles.label1}>Valor: R${item.preco.toFixed(2).toString().replace('.', ',')}</Text>
                              
                            </View>
                          ))}
                          <Text style={styles.label2}>Total: R${total.toFixed(2).toString().replace('.', ',')}</Text>
                        </ScrollView>

                <View>
                    <TouchableOpacity
                        style={styles.botaoCaixa1}
                        onPress={() => { FinalizaOrder() }}>
                        <Text style={styles.tituloPizzaria}>Finalizar a compra</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.botaoCaixa2}
                        onPress={() => { navigation.navigate('Customer') }}>
                        <Text style={styles.tituloPizzaria}>Voltar</Text>
                    </TouchableOpacity>
                </View>
            </ImageBackground>
        </View>
    );
}