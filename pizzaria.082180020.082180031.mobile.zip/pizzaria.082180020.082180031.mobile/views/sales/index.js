import React from 'react';
import {
    TextInput, Text, View, TouchableOpacity,
    Image, ScrollView, Alert, ImageBackground,
} from 'react-native';
import styles from './styles';

import defaultAdmin from "../../img/defaultAdmin.jpg";
import FormsView from '../../components/formsView';
import { useState, useEffect } from 'react';

import {
    obtemTodasVendas
} from '../../services/databaseAdm';

export default function Category({ navigation }) {
    const [vendas, setVendas] = useState([]);

    useEffect(
        () => {
            Carregar();
        }, []);

    async function Carregar() {
        try {
            let listaVendas = await obtemTodasVendas();
            setVendas(listaVendas);
        } catch (e) {
            alert(e.toString());
        }
    }

    return (
        <View style={styles.container}>
            <ImageBackground source={defaultAdmin} style={styles.imageBackground}>
                <ScrollView style={styles.container}>

                    <Text style={styles.tituloDaPizzaria}>Vendas:</Text>

                    <ScrollView style={styles.container}>
                        {
                            vendas.map((venda, index) => (
                                <FormsView item={venda}
                                    key={index.toString()} />
                            ))
                        }
                    </ScrollView>

                </ScrollView>

                <View>
                    <TouchableOpacity
                        style={styles.botaoCaixa1}
                        onPress={() => { navigation.navigate('Administrator') }}>
                        <Text style={styles.tituloPizzaria}>Voltar</Text>
                    </TouchableOpacity>
                </View>


            </ImageBackground>
        </View>
    );
}