import { StyleSheet, StatusBar } from "react-native";

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
    },
    tituloPizzaria: {
        fontSize: 20,
        color: '#000000',
        fontWeight: 'bold',
    },
    imageBackground: {
        flex: 1,
        resizeMode: 'cover',
        justifyContent: 'center',
        width: "100%",
        alignItems: 'center',
    },
    botaoCaixa1: {
        width: 300,
        height: 70,
        margin: 2,
        marginEnd: 5,
        borderColor: '#000000',
        backgroundColor: '#FF0000',
        borderWidth: 4,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: 'center',
    },
    botaoCaixa2: {
        width: 300,
        height: 70,
        margin: 2,
        marginEnd: 5,
        borderColor: '#000000',
        backgroundColor: '#00A86B',
        borderWidth: 4,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: 'center',
    },
    tituloDaPizzaria: {
        fontSize: 50,
        color: '#E32636',
        marginTop: 50,
        marginBottom: 25,
        fontWeight: 'bold',
    },
    titleLine: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 55,
        marginBottom: 5,
    },
    label: {
        fontSize: 35,
        marginTop: 3,
        color: '#AFEEEE',
        fontWeight: 'bold',
        marginRight: 10,
    },
    label1: {
        fontSize: 35,
        marginTop: 3,
        color: '#f4c430',
        fontWeight: 'bold',
        marginRight: 10,
    },
    label2: {
        fontSize: 35,
        marginTop: 3,
        color: '#E32636',
        fontWeight: 'bold',
        marginRight: 10,
    },

});


export default styles;