import React from 'react';
import {
    TextInput, Text, View, TouchableOpacity,
    Image, ScrollView, Alert, ImageBackground,
} from 'react-native';
import styles from "./styles";
import { obtemTodosProdutos, obtemTodasAsCategorias } from '../../services/databaseAdm';
import defaultFunds from "../../img/defaultFunds.jpg";
import { useState, useEffect } from 'react';
import ConteudoOrder from '../../components/conteudoOrder';
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function Choise({ navigation }) {
    const [produtos, setProdutos] = useState([]);
    const [order, setOrder] = useState([]);
    const [preco, setPreco] = useState(0.00);
    const [categorias, setCategorias] = useState([]);


    useEffect(
        () => {
            Carregar();
        }, []);

    async function Carregar() {
        try {
            let listaProdutos = await obtemTodosProdutos();
            let listaCategorias = await obtemTodasAsCategorias();
            setProdutos(listaProdutos);
            setCategorias(listaCategorias);
            console.log(listaProdutos)
            console.log(listaCategorias)
        } catch (e) {
            alert(e.toString());
        }
    }

    function adicionarItem(id, quantidade) {
        const objProduto = produtos.find(produto => produto.id == id);
        const existeNoPedido = order.find(item => item.item == objProduto.nome);
        let auxPedido = order;

        let objItemPedido = {
            item: objProduto.nome,
            quantidade: quantidade,
            preco: objProduto.preco * quantidade
        };
        if (existeNoPedido) {
            auxPedido[auxPedido.indexOf(existeNoPedido)] = objItemPedido;
        }
        else {
            auxPedido.push(objItemPedido);
        }
        setPreco(preco + parseFloat(objProduto.preco));
        console.log(preco)
        setOrder(auxPedido);
    }

    function Confirmar() {
        if (preco == 0) {
            alert('Carrinho vazio')
            return;
        }

        const stringJson = JSON.stringify(order);
        SalvaOrder(stringJson);
    }

    async function SalvaOrder(objJson) {
        try {
            await AsyncStorage.setItem('@order', objJson);

        } catch (e) {
            alert(e.toString());
        }
        navigation.navigate('Carrinho')
    }

    function diminuirItem(id, quantidade) {
        const objProduto = produtos.find(produto => produto.id == id);
        const existeNoPedido = pedido.find(item => item.item == objProduto.nome);
        let auxPedido = order;

        let objItemPedido = {
            item: objProduto.nome,
            quantidade: quantidade,
            preco: objProduto.preco * quantidade
        };
        auxPedido[auxPedido.indexOf(existeNoPedido)] = objItemPedido;
        setPreco(preco - parseFloat(objProduto.preco));
        setOrder(auxPedido);
    }

    function removerItem(id) {
        const objProduto = produtos.find(produto => produto.id == id);
        const existeNoPedido = order.find(item => item.item == objProduto.nome);
        let auxPedido = pedido;
        auxPedido.pop(auxPedido.indexOf(existeNoPedido))
        setPreco(preco - parseFloat(objProduto.preco));
        setPedido(auxPedido);
    }

    return (
        <View style={styles.container}>
            <ImageBackground source={defaultFunds} style={styles.imageBackground}>
                <ScrollView>

                    <Text style={styles.tituloDaPizzaria}>Escolher Produtos</Text>

                    <ScrollView style={styles.container}>{
                        categorias.map((categoria, index) => (
                            <ConteudoOrder categoria={categoria}
                                produtos={produtos}
                                adicionarItem={adicionarItem}
                                diminuirItem={diminuirItem}
                                removerItem={removerItem}
                                key={index.toString()} />
                        ))
                    }
                    </ScrollView>

                </ScrollView>
                <View>
                    <TouchableOpacity
                        style={styles.botaoCaixa1}
                        onPress={() => Confirmar()}>
                        <Text style={styles.tituloPizzaria}>Salvar</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.botaoCaixa2}
                        onPress={() => { navigation.navigate('Customer') }}>
                        <Text style={styles.tituloPizzaria}>Voltar</Text>
                    </TouchableOpacity>
                </View>
            </ImageBackground>
        </View>
    );
}