import React from 'react';
import {
    TextInput, Text, View, TouchableOpacity,
    Image, ScrollView, Alert, ImageBackground,
} from 'react-native';
import styles from "./styles";

import defaultFunds from "../../img/defaultFunds.jpg";

export default function Administrator({ navigation }) {
    return (
        <View style={styles.container}>
            <ImageBackground source={defaultFunds} style={styles.imageBackground}>
                <Text style={styles.tituloDaPizzaria}>Cliente</Text>
                <TouchableOpacity
                    style={styles.botaoCaixa1}
                    onPress={() => { navigation.navigate('Choise') }}>
                    <Text style={styles.tituloPizzaria}>Escolher Produtos</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.botaoCaixa1}
                    onPress={() => { navigation.navigate('Carrinho') }}>
                    <Text style={styles.tituloPizzaria}>Carrinho</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.botaoCaixa2}
                    onPress={() => { navigation.navigate('Home') }}>
                    <Text style={styles.tituloPizzaria}>Voltar</Text>
                </TouchableOpacity>

            </ImageBackground>
        </View>
    );
}