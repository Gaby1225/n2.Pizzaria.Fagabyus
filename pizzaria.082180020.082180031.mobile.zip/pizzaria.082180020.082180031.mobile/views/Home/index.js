import { StatusBar } from 'expo-status-bar';
import React from 'react';
import {
    TextInput, Text, View, TouchableOpacity,
    Image, ScrollView, Alert, ImageBackground,
} from 'react-native';
import styles from './styles';
//import AsyncStorage from '@react-native-async-storage/async-storage';
//import { useEffect, useState } from "react";
//import showPwd from "./img/showPwd.png";
//import hidePwd from "./img/hidePwd.png";
//import { Ionicons, Entypo } from '@expo/vector-icons';

import defaultFunds from "../../img/defaultFunds.jpg";
import fatia from "../../img/fatia.png";


/*import {
  createTableUser,
  getAllUsers,
} from './services/databaseUser';*/

export default function Home({ navigation }) {
    return (
        <View style={styles.container}>
            <ImageBackground source={defaultFunds} style={styles.imageBackground}>
                <Text style={styles.tituloDaPizzaria}>Pizzaria Fagabyus</Text>

                <Image source={fatia} style={styles.logo} />

                <TouchableOpacity
                    style={styles.botaoCaixa1}
                    onPress={() => { navigation.navigate('Administrator') }}>
                    <Text style={styles.tituloPizzaria}>Administrador</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.botaoCaixa2}
                    onPress={() => { navigation.navigate('Customer') }}>
                    <Text style={styles.tituloPizzaria}>Cliente</Text>
                </TouchableOpacity>

            </ImageBackground>
        </View>
    );
}

