import { createAppContainer, createSwitchNavigator } from "react-navigation";
import Home from './views/Home/index.js';
import Administrator from './views/administrator/index.js';
import Customer from './views/customer/index.js';
import Category from './views/category/index.js';
import Products from './views/products/index.js';
import Sales from './views/sales/index.js';
import Carrinho from './views/carrinho/index.js';
import Choise from './views/choise/index.js';

const Routes = createAppContainer(
  createSwitchNavigator({
    Home,
    Administrator,
    Category,
    Products,
    Sales,
    Customer,
    Carrinho,
    Choise,
    //qqr outro que precisar
  })
);

export default function App(){
  return(
    <Routes/>
  );
}