import {
    Text,
    TouchableOpacity,
    View,
} from "react-native";
import { Ionicons, Entypo } from '@expo/vector-icons';

import styles from "./styles";

export default function CadastroView({ item, editar, efetivaRemoverItem }) {
    return (
        <View style={styles.styleDirection}>
            <View>
                <Text style={styles.label}>{item.nome}</Text>
            </View>
            <View style={styles.botaoCaixa1}>

                <TouchableOpacity onPress={() => editar(item.id)}>
                    <Entypo name="edit" size={32} color="black" />
                </TouchableOpacity>

            </View>

            <View style={styles.botaoCaixa1}>
                <TouchableOpacity onPress={() => efetivaRemoverItem(item.id)}>
                    <Ionicons name="md-remove-circle" size={32} color="red" />
                </TouchableOpacity>

            </View>

        </View>
    );
}