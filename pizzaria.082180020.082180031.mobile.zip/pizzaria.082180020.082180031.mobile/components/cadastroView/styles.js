import { StyleSheet, StatusBar } from "react-native";

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'row',
    },
    tituloPizzaria: {
        fontSize: 30,
        color: '#000000',
        fontWeight: 'bold',
    },
    imageBackground: {
        flex: 1,
        resizeMode: 'cover',
        justifyContent: 'center',
        width: "100%",
        alignItems: 'center',
    },
    botaoCaixa1: {
        width: 50,
        height: 70,
        margin: 2,
        marginEnd: 5,
        borderColor: '#000000',
        backgroundColor: '#f4c430',
        borderWidth: 4,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: 'center',
    },

    styleDirection:{
        flexDirection: 'row',
    },

    tituloDaPizzaria: {
        fontSize: 50,
        color: '#E32636',
        marginTop: 50,
        marginBottom: 25,
        fontWeight: 'bold',
        alignItems: "center",
        justifyContent: 'center',
    },
    entrada: {
        backgroundColor: "#AFEEEE",
        width: 300,
        height: 50,
        borderRadius: 10,
        alignContent: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        marginBottom: 25,
        fontSize: 20
    },
    label: {
        fontSize: 35,
        marginTop: 10,
        color: '#000000',
        fontWeight: 'bold',
        marginRight: 10,
        alignItems: "center",
        justifyContent: 'center',
    },

});


export default styles;