import {
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Entypo } from '@expo/vector-icons';
import { useState } from 'react';
import styles from "./styles";
import { Alert } from "react-native";

export default function CadastroViewNumber({ item, removerItem, adicionarItem, diminuirItem, exibirCategoria }) {

  const [quantidade, setQuantidade] = useState(0);

  function alteraQuantidade(sinal) {
    if (sinal == '+') {
      setQuantidade(quantidade + 1);
      adicionarItem(item.id, quantidade + 1);
    }
    else if (sinal == '-' && quantidade > 0) {
      setQuantidade(quantidade - 1);
      if (quantidade == 1) {
        removerItem(item.id);
      }
      else {
        diminuirItem(item.id, quantidade - 1);
      }
    }
  }

  function mostrarDescricao() {
    Alert.alert('Descrição', item.descricao);
  }

  if (item.categoria == exibirCategoria) {
    return (
      <View>
        <TouchableOpacity style={styles.container2} onPress={() => mostrarDescricao()}> 
          <View>
            <Text style={styles.label}>{item.nome}</Text>
            <Text style={styles.label}>R${parseFloat(item.preco).toFixed(2).toString().replace('.', ',')}</Text>
          </View>
          <View >
            <TouchableOpacity onPress={() => alteraQuantidade('+')}>
              <Entypo name="circle-with-plus" size={32} color="#f4c430" />
            </TouchableOpacity>
            <Text style={styles.label2}>{quantidade}</Text>
            <TouchableOpacity onPress={() => alteraQuantidade('-')}>
              <Entypo name="circle-with-minus" size={32} color="#f4c430" />
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </View>
    );
  }
}