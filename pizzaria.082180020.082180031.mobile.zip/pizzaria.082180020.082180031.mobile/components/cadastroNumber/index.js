import React from 'react';
import styles from "./styles";
import {
    Text,
    TextInput,
    View,
} from "react-native";

import defaultAdmin from "../../img/defaultAdmin.jpg";

export default function CadastroNumber({ placeholder, texto, height, setTexto, titulo }) {
    return (
        <View style={styles.container}>
            <Text style={styles.label}>{titulo}</Text>
            <TextInput style={[styles.entrada, { height: height || 50 }]}
                keyboardType={'decimal-pad'}
                placeholder={placeholder}
                onChangeText={(text) => setTexto(text.replace(',','.'))}
                value={texto.replace('.',',')} />

        </View>
    );
}