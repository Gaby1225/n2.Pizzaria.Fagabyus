import {
  Text,
  View,
} from "react-native";

import styles from "./styles";

export default function FormsView({ item }) {
  console.log(Date(item.data))
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{item.descricao.trim()}</Text>
      <Text style={styles.label}>{item.data}</Text>
      <Text style={styles.label2}>Total: R${item.total.toFixed(2).toString().replace('.', ',')}</Text>
      <Text></Text>
    </View>
  );
}