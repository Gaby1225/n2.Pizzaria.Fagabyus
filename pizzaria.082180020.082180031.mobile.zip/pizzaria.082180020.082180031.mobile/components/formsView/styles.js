import { StyleSheet, StatusBar } from "react-native";

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    label: {
        fontSize: 25,
        color: '#000000',
        fontWeight: 'bold',
        textAlign: 'justify',
    },
    label2: {
        fontSize: 25,
        color: '#E32636',
        fontWeight: 'bold',
    },

});


export default styles;