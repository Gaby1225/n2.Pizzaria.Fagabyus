import {
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import styles from "./styles";
import CadastroViewNumber from '../cadastroViewNumber';

export default function ConteudoOrder({ categoria, produtos, adicionarItem, diminuirItem, removerItem }) {
  return (
    <View style={styles.container2}>
        <View>
          <Text style={styles.label}>{categoria.nome}</Text>
        </View>
         <View>{
          produtos.map((produto, index) => (
            <CadastroViewNumber item={produto}
              adicionarItem={adicionarItem}
              diminuirItem={diminuirItem}
              removerItem={removerItem}
              exibirCategoria={categoria.nome}
              key={index.toString()} />
          ))
        }
        </View>
    </View>
  );
}