import React from 'react';
import {
    TextInput, Text, View, TouchableOpacity,
    Image, ScrollView, Alert, ImageBackground,
} from 'react-native';
import styles from "./styles";

import defaultAdmin from "../../img/defaultAdmin.jpg";

export default function CadastroLinha({ placeholder, texto, height, multiline, setTexto, titulo }) {
    return (
        <View style={styles.container}>
            <Text style={styles.label}>{titulo}</Text>
            <TextInput style={[styles.entrada, { height: height || 50 }]}
                keyboardType={'default'}
                placeholder={placeholder}
                onChangeText={(text) => setTexto(text)}
                value={texto}
                multiline={multiline || false} />

        </View>
    );
}