import React from 'react';
import {
    TextInput, Text, View, TouchableOpacity,
    Image, ScrollView, Alert, ImageBackground,
} from 'react-native';
import styles from "./styles";
import { useState, useEffect } from 'react';

import { Dropdown } from "react-native-element-dropdown";
import defaultAdmin from "../../img/defaultAdmin.jpg";

export default function CadastroDropdown({ categoria, lista, titulo, setCategoria }) {
    const [isFocus, setIsFocus] = useState(false);
    return (
        <View style={styles.container}>
            <Text style={styles.label}>{titulo}</Text>
            <Dropdown data={lista}
                style={styles.entrada}
                placeholder={!isFocus ? 'Escolha a Categoria' : '...'}
                placeholderStyle={styles.placeholder}
                selectedTextStyle={styles.dropdownItems}
                labelField="nome"
                valueField="nome"
                value={categoria}
                onFocus={() => setIsFocus(true)}
                onBlur={() => setIsFocus(false)}
                onChange={item => {
                    setCategoria(item.nome);
                    setIsFocus(false);
                }} />

        </View>
    );
}