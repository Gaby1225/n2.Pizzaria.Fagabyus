import { StyleSheet, StatusBar } from "react-native";

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
    },

    lineOfButton: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginBottom: 5,
    },

    lineOfButtons: {
        flex: 0.5,
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginBottom: 5,
        marginTop: 10,
    },

    lineOfList: {
        flex: 0.5,
        flexDirection: 'row',
        marginBottom: 5,
        marginTop: 10,
    },

    lineOfRegister: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginBottom: 5,
        marginTop: 20,
    },

    titleLine: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 55,
        marginBottom: 5,
    },

    label: {
        fontSize: 35,
        color: '#F5DEB3',
        fontWeight: 'bold',
        marginRight: 10,
    },

    labelClear: {
        fontSize: 30,
        color: '#F4C430',
        fontWeight: 'bold',
    },
    campoEdicao: {
        backgroundColor: '#DCDCDC',
        width: '80%',
        height: 40,
        fontSize: 17,
        fontWeight: 'bold',
        borderRadius: 10,
        paddingHorizontal: 10,
    },

    campoSenha: {
        width: '55%',
        marginRight: 10,
    },
    campoLabelsTexts: {
        width: '65%',
        marginRight: 10,
    },
    imgExibeSenha: {
        width: 32,
        height: 32,
    },
    listaUsers: {
        width: '98%',
        height: '100%',
        backgroundColor: '#FFF',
        marginTop: 20,
    },

});


export default styles;